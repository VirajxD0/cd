#inclde <stdio.h>       // Error: misspelled "include"
#includ <conio.h>       // Error: again misspelled

int main() {
    int a = 10;
    float b = 20.5.6;   // Error: invalid number format
    char c = 'ab';      // Error: char must be one character
    string name = "John; // Error: unclosed string
    int 123abc = 5;     // Error: invalid identifier (starts with number)
    double d = 3.14.15; // Error: invalid float

    if (a < b) {
        a = a + 1;
    }

    // Missing semicolon below
    return 0
}
