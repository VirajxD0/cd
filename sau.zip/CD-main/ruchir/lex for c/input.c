#include<stdio.h>
#include<conio.h>

int main(){
    int a = 10;
    float b = 10.5;
    char c = 'x';

    if(a<b){
        a=a+1;
    }
    return 0;
}