SELECT name FROM employees WHERE department = 'HR';
INSERT INTO logs VALUES (1, 'entry');
