class X {
    int 1bad = 5;
    X::foo();
  }
  