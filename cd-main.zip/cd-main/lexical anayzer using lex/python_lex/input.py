def greet():
    message = "Hello Python"
    if message:
        print("Good")
