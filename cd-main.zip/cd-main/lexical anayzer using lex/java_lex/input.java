public class Test {
    public static void main(String[] args) {
        String greeting = "Welcome to Java";
        if (greeting != null) {
            System.out.println("Hello");
        }
    }
}
