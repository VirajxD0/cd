int main() {
    int x = 10;
    char* msg = "Hello world";
    if (x > 5) {
        return 0;
    }
}
