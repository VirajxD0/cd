SELECT name, age FROM users WHERE age >= 18;
INSERT INTO employees VALUES ('John', 25, 'Engineer');
-- This is a comment
UPDATE users SET age = 30 WHERE name = 'Alice';
DELETE FROM employees WHERE age < 20;