int main() {
    int a = 10;
    float b = 3.14;
    if (a == 10) {
        a = a + b;
    }
}
