int main() {
    float x = 3.14;
    if (x < 10) x = x + 1;
}