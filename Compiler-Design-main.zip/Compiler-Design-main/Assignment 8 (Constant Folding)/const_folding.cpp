#include <iostream>
#include <vector>
#include <unordered_map>
#include <sstream>

using namespace std;

struct Quadruple {
    string op;
    string arg1;
    string arg2;
    string result;
};

bool isNumber(const string& s) {
    for (char c : s)
        if (!isdigit(c)) return false;
    return true;
}

int compute(string op, int a, int b) {
    if (op == "+") return a + b;
    if (op == "-") return a - b;
    if (op == "*") return a * b;
    if (op == "/") return b != 0 ? a / b : 0;
    return 0;
}

void optimize(vector<Quadruple>& quads) {
    unordered_map<string, string> constMap;

    for (auto& q : quads) {
        // Constant propagation
        if (constMap.count(q.arg1)) q.arg1 = constMap[q.arg1];
        if (constMap.count(q.arg2)) q.arg2 = constMap[q.arg2];

        // Constant folding
        if (isNumber(q.arg1) && isNumber(q.arg2)) {
            int val1 = stoi(q.arg1);
            int val2 = stoi(q.arg2);
            int res = compute(q.op, val1, val2);
            q.op = "=";
            q.arg1 = to_string(res);
            q.arg2 = "-";
            constMap[q.result] = q.arg1; // record result as constant
        } else if (q.op == "=" && isNumber(q.arg1)) {
            constMap[q.result] = q.arg1;
        } else {
            constMap.erase(q.result); // value changed, not constant anymore
        }
    }
}

void printQuads(const vector<Quadruple>& quads) {
    for (const auto& q : quads) {
        cout << "(" << q.op << ", " << q.arg1 << ", " << q.arg2 << ", " << q.result << ")\n";
    }
}

#include <fstream>

int main() {
    vector<Quadruple> quads;
    ifstream infile("C:\\1VU\\TY\\Semester 6\\Compiler Design\\Assignment 8\\input.txt");
    if (!infile) {
        cerr << "Error opening input.txt" << endl;
        return 1;
    }
    string op, arg1, arg2, result;
    while (infile >> op >> arg1 >> arg2 >> result) {
        quads.push_back({op, arg1, arg2, result});
    }
    infile.close();

    cout << "Before Optimization:\n";
    printQuads(quads);

    optimize(quads);

    cout << "\nAfter Optimization:\n";
    printQuads(quads);

    return 0;
}

