SELECT name, age FROM users WHERE age >= 18 AND city = 'New York';

INSERT INTO orders (id, product, quantity) VALUES (1, 'Laptop', 5);

UPDATE users SET age = 30 WHERE name = 'Alice';

DELETE FROM orders WHERE id = 2;