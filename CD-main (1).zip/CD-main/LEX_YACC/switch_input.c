switch(x) {
    case 1:
        x = x + 1;
        break;
    case 2:
        x = x * 2;
        break;
    default:
        x = 0;
        break;
}
