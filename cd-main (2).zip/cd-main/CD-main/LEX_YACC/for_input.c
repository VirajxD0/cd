for(int i = 0;i < b; i++ ){
    a = a + i;
}