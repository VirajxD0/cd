int main() {
    int a = 10/5;
    float b = 3.14+1;
    if (a == 10) {
        a = a - b;
    }
}