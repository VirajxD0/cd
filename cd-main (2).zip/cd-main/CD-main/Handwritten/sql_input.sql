SELECT name, age FROM users WHERE name = "neel";
