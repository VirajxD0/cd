
def add():
    print(1+1)    

0add()