int main() {
    int x = 42;
    float y = 3.14;
    if (x >= 10) {
        y = y * 2.0;
    }
    return 0;
}